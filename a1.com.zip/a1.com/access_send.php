<?php
if ($_POST['']);
$file=fopen('access.txt','a+');
fputs($file,$_POST['email'].PHP_EOL);
fclose($file);
#echo 'Успешно';
#echo $_POST['email'];
header('Location: index.html');
?>