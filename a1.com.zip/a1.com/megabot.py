import time
import telebot
import random
from PIL import Image
import socket
import os
import ftplib
import random

PORT = 6666
pin = None

BOT_TOKEN = '5066915411:AAGvQot-DCyoGu_cyUyaRrftasIvhmkyhJY'

online = 0

dirname = os.path.join(os.getcwd(), 'docs')

def process(req):
    global online

    if 'login' in req:
        req = req.split()[1]
        file = open("/var/www/a1.com/access.txt",'r')
        l = [line.split('\n') for line in file]
        table = []
        for i in range (0,len(l)):
            table.append(l[i])
        file.close()

        for i in range (0,len(table)):
            point = table[i]
            if str(point[0]) == str(req):
                global pin
                pin = random.randint(0, 500)
                file = open("/var/www/a1.com/b2.com/pins.txt",'a')
                file.write(str(pin) + "\n")
                file.close()
                file = open("/var/www/a1.com/c3.com/logs.txt",'a')
                file.write("Пользователь " + str(req) + " заходит через сервер на порту " + str(PORT) + "\n")
                file.close()
                return "Найден пользователь " + str(req) + "Пин выслан"

    if 'pin' in req:
        
        req = req.split()[1]
        if str(req) == str(pin):
            file = open("/var/www/a1.com/c3.com/logs.txt",'a')
            file.write("Пользователь прошёл авторизацию с пином " + str(pin) + "\n")
            file.close()
            online = 1
            return "Пользователь прошёл авторизацию"

    if str(req) == "chat" and online == 1:
        return "chat"
    elif str(req) == "chat" and online == 0:
        return "Вы не выполнили вход"

PORT = 6666

sock = socket.socket()
sock.bind(('', PORT))
sock.listen()
print("Прослушиваем порт", PORT)

while True:
    conn, addr = sock.accept()
    
    request = conn.recv(1024).decode()
    print(request)
    
    response = process(request)

    conn.send(response.encode())
    if response == "False":
        break

    if response == "chat":
        while True:
            conn, addr = sock.accept()
    
            request = conn.recv(1024).decode()

            file = open("/var/www/a1.com/chat.txt",'a')
            file.write(str(request) + "\n")
            file.close()

            bot = telebot.TeleBot(BOT_TOKEN)

            @bot.message_handler(content_types=['text'])
            def chat(message): 
                bot.send_message(message.chat.id, str(request))
                response = str(message)
                conn.send(response.encode())

            request = conn.recv(1024).decode()
            
    
bot.polling()
conn.close()