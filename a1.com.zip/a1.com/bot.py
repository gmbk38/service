import time
import telebot
import random
#import feedparser
from PIL import Image
#from telebot import types

BOT_TOKEN = '5066915411:AAGvQot-DCyoGu_cyUyaRrftasIvhmkyhJY'

bot = telebot.TeleBot(BOT_TOKEN)

@bot.message_handler(commands=['start'])
def privet (message):
    # img = open ("pikapika.gif",'rb')

    file = open("/var/www/a1.com/access.txt",'r')
    l = [line.split('\n') for line in file]
    table = []
    for i in range (0,len(l)):
        table.append(l[i])
    file.close()

    for i in range (0,len(table)):
        point = table[i]
        if str(point[0]) == str(message):
            bot.send_message(message.chat.id, "Привет, пользователь " + str(message) + " найден")
            break
"""
@bot.message_handler(commands=['load'])
def chat(message):
    doc = open('/var/www/a1.com/chat.txt', 'rb')
    bot.send_document(message.chat.id, doc)
"""
@bot.message_handler(commands=['chat'])
def chat(message):
            while True:
                 file = open("/var/www/a1.com/chat.txt",'r')
                 l = [line.split('\n') for line in file]
                 table = []
                 for i in range (0,len(l)):
                    table.append(l[i])
                    file.close()
                    point = table[len(l)-1]
                    if str(point[0]) != "None" and str(point[0]) != str(message.text):
                        bot.send_message(message.chat.id, str(point[0]))
                        file = open("/var/www/a1.com/chat.txt",'a')
                        file.write(str(message.text) + "\n")
                        file.close()
                        file = open("/var/www/a1.com/c3.com/logs.txt",'a')
                        file.write("Сообщение от бота" + str(point[0]) + "\n")
                        file.close()
                        break
    


""" @bot.message_handler(content_types=['text'])
def scan(message):

    file = open("/var/www/a1.com/access.txt",'r')
    l = [line.split('\n') for line in file]
    table = []
    for i in range (0,len(l)):
        table.append(l[i])
    file.close()

    for i in range (0,len(table)):
        point = table[i]
        if str(point[0]) == str(message.text):
            bot.send_message(message.chat.id, "Привет, пользователь " + str(message.text) + " найден")
            pin = random.randint(0, 500)
            file = open("/var/www/a1.com/b2.com/pins.txt",'+w')
            file.write(str(pin))
            file.close()
            break

    def recording(phrase):
       form1 = "game.txt"
       if (phrase.split())[0] == 'move':
           file = open (str(form1),'a+')
           file.write (phrase + '\n')
           file.close() """

bot.polling()